﻿using System;

namespace JollyPirate
{
    class Program
    {
        static void Main(string[] args)
        {
            controller.User c = new controller.User();

            c.StartSystem();
        }
    }
}
