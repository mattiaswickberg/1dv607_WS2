﻿

namespace JollyPirate.controller
{
    class MemberController
    {
        internal model.Roster Roster;
        internal view.MemberView MemberView;
        internal view.BoatView BoatView;

        internal BoatController BoatController
        {
            get => new BoatController(BoatView, Roster);
        }

        public MemberController(model.Roster roster, view.MemberView memberView, view.BoatView boatView)
        {
            Roster = roster;
            MemberView = memberView;
            BoatView = boatView;
        }

        public void EditMember(model.Member member)
        {
            if (member.GetMemberId() != "0")
            {
                MemberView.WriteMemberToConsole(member.ToString(true));
                MemberView.EditMemberMenu();
                string choice = System.Console.ReadLine();

                if (choice == "1")
                {
                    string name = MemberView.GetNewMemberName();
                    member.SetName(name);
                    Roster.SaveMembersToFile();
                    MemberView.Success();
                }
                else if (choice == "2")
                {
                    string personalNumber = MemberView.GetPersonalNumber();
                    member.SetPersonalNumber(personalNumber);
                    Roster.SaveMembersToFile();
                    MemberView.Success();
                }
                else if (choice == "3")
                {
                    BoatController.BoatMenu(member);
                }
                else
                {
                    MemberView.InvalidChoice();
                }
                MemberView.PressToContinue();
            }
            else
            {
                MemberView.MemberNotFound();
            }
        }
    }
}
