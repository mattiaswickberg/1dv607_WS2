﻿using System;

namespace JollyPirate.controller
{
    class User
    {
        internal view.Console Console
        {
            get => new view.Console();
        }

        internal view.BoatView BoatView
        {
            get => new view.BoatView();
        }

        internal view.MemberView MemberView
        {
            get => new view.MemberView();
        }        

        internal model.Roster Roster
        {
            get => new model.Roster(Console, MemberView);
        }

        internal RosterController RosterController
        {
            get => new RosterController(MemberView, Roster);
        }

        internal MemberController MemberController
        {
            get => new MemberController(Roster, MemberView, BoatView);
        }

        public void StartSystem()
        {
            string input;
            bool systemActive = true;

            while(systemActive)
            {
                input = Console.DisplayMenu();

                switch (input)
                {
                    case "quit":
                        {
                            Roster.SaveMembersToFile();
                            systemActive = false;
                            break;
                        }
                    case "1":
                        {
                            RosterController.AddNewMember();
                            break;
                        }
                    case "2":
                        {
                            Roster.ListMembers();
                            break;
                        }
                    case "3":
                        {
                            Roster.ListMembersWithDetails();
                            break;
                        }
                    case "4":
                        {
                            Roster.ViewMember();
                            break;
                        }
                    case "5":
                        {
                            string memberId = EditMemberById();
                            model.Member member = Roster.FindMemberById(memberId);
                            MemberController.EditMember(member);
                            break;
                        }
                    case "6":
                        {
                            RosterController.DeleteMember();
                            break;
                        }
                    default:
                        {
                            Console.InvalidChoice();
                            break;
                        }
                }                
            }
        }
        public string EditMemberById()
        {
            System.Console.WriteLine("Type the Id of the member you want to edit:");
            return System.Console.ReadLine();
        }        
    }
}
